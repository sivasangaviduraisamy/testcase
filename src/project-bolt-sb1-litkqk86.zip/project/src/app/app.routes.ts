import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    redirectTo: '/dashboard',
    pathMatch: 'full'
  },
  {
    path: 'dashboard',
    loadComponent: () => import('./components/dashboard/dashboard.component').then(m => m.DashboardComponent)
  },
  {
    path: 'account-opening',
    loadComponent: () => import('./components/account-opening/account-opening.component').then(m => m.AccountOpeningComponent)
  },
  {
    path: 'customer-management',
    loadComponent: () => import('./components/customer-management/customer-management.component').then(m => m.CustomerManagementComponent)
  },
  {
    path: 'reports',
    loadComponent: () => import('./components/reports/reports.component').then(m => m.ReportsComponent)
  },
  {
    path: 'compliance',
    loadComponent: () => import('./components/compliance/compliance.component').then(m => m.ComplianceComponent)
  },
  {
    path: 'settings',
    loadComponent: () => import('./components/settings/settings.component').then(m => m.SettingsComponent)
  }
];
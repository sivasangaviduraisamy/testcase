import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { AccountOpeningComponent } from './components/account-opening/account-opening.component';
import { CustomerManagementComponent } from './components/customer-management/customer-management.component';
import { ReportsComponent } from './components/reports/reports.component';
import { NavigationComponent } from './components/navigation/navigation.component';
import { DemographicDetailsComponent } from './components/steps/demographic-details/demographic-details.component';
import { KycVerificationComponent } from './components/steps/kyc-verification/kyc-verification.component';
import { ProductSelectionComponent } from './components/steps/product-selection/product-selection.component';
import { WelcomeKitComponent } from './components/steps/welcome-kit/welcome-kit.component';
import { FinalStepComponent } from './components/steps/final-step/final-step.component';
import { AuditTrailComponent } from './components/audit-trail/audit-trail.component';
import { ComplianceComponent } from './components/compliance/compliance.component';
import { BulkProcessingComponent } from './components/bulk-processing/bulk-processing.component';
import { NotificationsComponent } from './components/notifications/notifications.component';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    AccountOpeningComponent,
    CustomerManagementComponent,
    ReportsComponent,
    NavigationComponent,
    DemographicDetailsComponent,
    KycVerificationComponent,
    ProductSelectionComponent,
    WelcomeKitComponent,
    FinalStepComponent,
    AuditTrailComponent,
    ComplianceComponent,
    BulkProcessingComponent,
    NotificationsComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    FormsModule,
    RouterModule.forRoot([
      { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
      { path: 'dashboard', component: DashboardComponent },
      { path: 'account-opening', component: AccountOpeningComponent },
      { path: 'customers', component: CustomerManagementComponent },
      { path: 'reports', component: ReportsComponent },
      { path: 'audit-trail', component: AuditTrailComponent },
      { path: 'compliance', component: ComplianceComponent },
      { path: 'bulk-processing', component: BulkProcessingComponent },
      { path: 'notifications', component: NotificationsComponent }
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
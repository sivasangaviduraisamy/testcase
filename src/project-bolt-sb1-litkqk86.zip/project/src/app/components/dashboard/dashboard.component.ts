import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

interface MetricCard {
  title: string;
  value: string;
  change: string;
  changeType: 'positive' | 'negative' | 'neutral';
  icon: string;
  color: string;
}

interface RecentApplication {
  id: string;
  customerName: string;
  accountType: string;
  status: 'pending' | 'approved' | 'rejected' | 'in-review';
  submittedDate: Date;
  progress: number;
}

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  metrics: MetricCard[] = [
    {
      title: 'Total Applications Today',
      value: '47',
      change: '+12%',
      changeType: 'positive',
      icon: 'M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z',
      color: 'blue'
    },
    {
      title: 'Pending Approvals',
      value: '23',
      change: '+5',
      changeType: 'neutral',
      icon: 'M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z',
      color: 'orange'
    },
    {
      title: 'Approved Today',
      value: '31',
      change: '+18%',
      changeType: 'positive',
      icon: 'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z',
      color: 'green'
    },
    {
      title: 'KYC Verifications',
      value: '15',
      change: '-3%',
      changeType: 'negative',
      icon: 'M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z',
      color: 'purple'
    },
    {
      title: 'Revenue Generated',
      value: '$127,450',
      change: '+24%',
      changeType: 'positive',
      icon: 'M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z',
      color: 'indigo'
    },
    {
      title: 'Active Customers',
      value: '2,847',
      change: '+156',
      changeType: 'positive',
      icon: 'M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z',
      color: 'teal'
    }
  ];

  recentApplications: RecentApplication[] = [
    {
      id: 'ACC-2024-001',
      customerName: 'Sarah Johnson',
      accountType: 'Premium Savings',
      status: 'pending',
      submittedDate: new Date('2024-01-15'),
      progress: 75
    },
    {
      id: 'ACC-2024-002',
      customerName: 'Michael Chen',
      accountType: 'Business Current',
      status: 'approved',
      submittedDate: new Date('2024-01-15'),
      progress: 100
    },
    {
      id: 'ACC-2024-003',
      customerName: 'Emily Rodriguez',
      accountType: 'Student Account',
      status: 'in-review',
      submittedDate: new Date('2024-01-14'),
      progress: 45
    },
    {
      id: 'ACC-2024-004',
      customerName: 'David Thompson',
      accountType: 'Investment Account',
      status: 'pending',
      submittedDate: new Date('2024-01-14'),
      progress: 60
    },
    {
      id: 'ACC-2024-005',
      customerName: 'Lisa Wang',
      accountType: 'Joint Account',
      status: 'rejected',
      submittedDate: new Date('2024-01-13'),
      progress: 30
    }
  ];

  quickActions = [
    {
      title: 'New Account Opening',
      description: 'Start a new customer account opening process',
      icon: 'M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z',
      route: '/account-opening',
      color: 'blue'
    },
    {
      title: 'Bulk KYC Processing',
      description: 'Process multiple KYC verifications',
      icon: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4',
      route: '/compliance',
      color: 'green'
    },
    {
      title: 'Generate Reports',
      description: 'Create daily, weekly, or monthly reports',
      icon: 'M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z',
      route: '/reports',
      color: 'purple'
    },
    {
      title: 'Customer Search',
      description: 'Find and manage existing customers',
      icon: 'M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z',
      route: '/customer-management',
      color: 'indigo'
    }
  ];

  alerts = [
    {
      type: 'warning',
      title: 'KYC Documents Expiring',
      message: '5 customers have KYC documents expiring within 30 days',
      time: '2 hours ago'
    },
    {
      type: 'info',
      title: 'System Maintenance',
      message: 'Scheduled maintenance window: Tonight 11 PM - 2 AM',
      time: '4 hours ago'
    },
    {
      type: 'success',
      title: 'Monthly Target Achieved',
      message: 'Account opening target for January exceeded by 15%',
      time: '1 day ago'
    }
  ];

  ngOnInit() {
    // Initialize dashboard data
  }

  getStatusBadgeClass(status: string): string {
    const classes = {
      'pending': 'badge-warning',
      'approved': 'badge-success',
      'rejected': 'badge-error',
      'in-review': 'badge-info'
    };
    return classes[status as keyof typeof classes] || 'badge-info';
  }

  getMetricColorClass(color: string): string {
    const colors = {
      'blue': 'metric-blue',
      'green': 'metric-green',
      'orange': 'metric-orange',
      'purple': 'metric-purple',
      'indigo': 'metric-indigo',
      'teal': 'metric-teal'
    };
    return colors[color as keyof typeof colors] || 'metric-blue';
  }

  getActionColorClass(color: string): string {
    const colors = {
      'blue': 'action-blue',
      'green': 'action-green',
      'purple': 'action-purple',
      'indigo': 'action-indigo'
    };
    return colors[color as keyof typeof colors] || 'action-blue';
  }
}
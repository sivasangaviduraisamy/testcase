import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';

interface Step {
  id: number;
  title: string;
  description: string;
  completed: boolean;
  active: boolean;
}

@Component({
  selector: 'app-account-opening',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './account-opening.component.html',
  styleUrls: ['./account-opening.component.scss']
})
export class AccountOpeningComponent implements OnInit {
  currentStep = 1;
  totalSteps = 5;
  
  steps: Step[] = [
    { id: 1, title: 'Personal Details', description: 'Basic demographic information', completed: false, active: true },
    { id: 2, title: 'KYC Verification', description: 'Identity and document verification', completed: false, active: false },
    { id: 3, title: 'Product Selection', description: 'Choose account type and features', completed: false, active: false },
    { id: 4, title: 'Welcome Kit', description: 'Delivery preferences and setup', completed: false, active: false },
    { id: 5, title: 'Final Review', description: 'Review and submit application', completed: false, active: false }
  ];

  // Forms for each step
  personalDetailsForm!: FormGroup;
  kycForm!: FormGroup;
  productForm!: FormGroup;
  welcomeKitForm!: FormGroup;

  // Product options
  accountTypes = [
    { id: 'savings', name: 'Premium Savings Account', minBalance: 10000, features: ['High Interest Rate', 'Free ATM Transactions', 'Mobile Banking'] },
    { id: 'current', name: 'Business Current Account', minBalance: 25000, features: ['Unlimited Transactions', 'Overdraft Facility', 'Business Banking'] },
    { id: 'salary', name: 'Salary Account', minBalance: 0, features: ['Zero Balance', 'Salary Processing', 'Personal Banking'] },
    { id: 'student', name: 'Student Account', minBalance: 500, features: ['Low Minimum Balance', 'Educational Loans', 'Student Benefits'] }
  ];

  selectedDocuments: File[] = [];
  uploadProgress = 0;

  constructor(private fb: FormBuilder) {
    this.initializeForms();
  }

  ngOnInit() {
    this.updateStepStates();
  }

  initializeForms() {
    this.personalDetailsForm = this.fb.group({
      firstName: ['', [Validators.required, Validators.minLength(2)]],
      lastName: ['', [Validators.required, Validators.minLength(2)]],
      email: ['', [Validators.required, Validators.email]],
      phone: ['', [Validators.required, Validators.pattern(/^\+?[1-9]\d{1,14}$/)]],
      dateOfBirth: ['', Validators.required],
      gender: ['', Validators.required],
      nationality: ['', Validators.required],
      occupation: ['', Validators.required],
      annualIncome: ['', [Validators.required, Validators.min(0)]],
      address: ['', Validators.required],
      city: ['', Validators.required],
      state: ['', Validators.required],
      zipCode: ['', [Validators.required, Validators.pattern(/^\d{5,6}$/)]],
      country: ['', Validators.required]
    });

    this.kycForm = this.fb.group({
      idType: ['', Validators.required],
      idNumber: ['', Validators.required],
      panNumber: ['', [Validators.required, Validators.pattern(/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/)]],
      aadharNumber: ['', [Validators.required, Validators.pattern(/^\d{12}$/)]],
      passportNumber: [''],
      drivingLicense: ['']
    });

    this.productForm = this.fb.group({
      accountType: ['', Validators.required],
      initialDeposit: ['', [Validators.required, Validators.min(500)]],
      debitCard: [true],
      internetBanking: [true],
      mobileBanking: [true],
      smsAlerts: [true],
      emailStatements: [true]
    });

    this.welcomeKitForm = this.fb.group({
      deliveryAddress: ['', Validators.required],
      deliveryCity: ['', Validators.required],
      deliveryState: ['', Validators.required],
      deliveryZip: ['', Validators.required],
      preferredDeliveryTime: ['', Validators.required],
      communicationPreference: ['email', Validators.required]
    });
  }

  updateStepStates() {
    this.steps.forEach((step, index) => {
      step.active = step.id === this.currentStep;
      step.completed = step.id < this.currentStep;
    });
  }

  nextStep() {
    if (this.validateCurrentStep()) {
      if (this.currentStep < this.totalSteps) {
        this.currentStep++;
        this.updateStepStates();
      }
    }
  }

  previousStep() {
    if (this.currentStep > 1) {
      this.currentStep--;
      this.updateStepStates();
    }
  }

  goToStep(stepNumber: number) {
    if (stepNumber <= this.currentStep || this.steps[stepNumber - 1].completed) {
      this.currentStep = stepNumber;
      this.updateStepStates();
    }
  }

  validateCurrentStep(): boolean {
    switch (this.currentStep) {
      case 1:
        return this.personalDetailsForm.valid;
      case 2:
        return this.kycForm.valid && this.selectedDocuments.length >= 2;
      case 3:
        return this.productForm.valid;
      case 4:
        return this.welcomeKitForm.valid;
      case 5:
        return true;
      default:
        return false;
    }
  }

  onFileSelected(event: any) {
    const files = Array.from(event.target.files) as File[];
    this.selectedDocuments = [...this.selectedDocuments, ...files];
    this.simulateUpload();
  }

  removeDocument(index: number) {
    this.selectedDocuments.splice(index, 1);
  }

  simulateUpload() {
    this.uploadProgress = 0;
    const interval = setInterval(() => {
      this.uploadProgress += 10;
      if (this.uploadProgress >= 100) {
        clearInterval(interval);
      }
    }, 200);
  }

  submitApplication() {
    if (this.validateAllSteps()) {
      // Simulate application submission
      console.log('Application submitted successfully!');
      // Here you would typically send the data to your backend
    }
  }

  validateAllSteps(): boolean {
    return this.personalDetailsForm.valid && 
           this.kycForm.valid && 
           this.productForm.valid && 
           this.welcomeKitForm.valid &&
           this.selectedDocuments.length >= 2;
  }

  getProgressPercentage(): number {
    return (this.currentStep / this.totalSteps) * 100;
  }

  getSelectedAccountType() {
    const selectedId = this.productForm.get('accountType')?.value;
    return this.accountTypes.find(type => type.id === selectedId);
  }

  formatCurrency(amount: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR'
    }).format(amount);
  }
}
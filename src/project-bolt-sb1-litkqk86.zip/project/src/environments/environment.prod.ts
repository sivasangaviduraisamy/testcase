export const environment = {
  production: true,
  apiUrl: 'https://api.bankingsystem.com',
  version: '1.0.0'
};